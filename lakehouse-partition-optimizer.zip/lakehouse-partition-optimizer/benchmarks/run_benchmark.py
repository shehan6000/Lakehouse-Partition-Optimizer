"""
benchmarks/run_benchmark.py
----------------------------
Full comparative benchmark:
  - Flat (no partitioning)
  - Hive static partitioning
  - Z-ordering
  - RL agent (if trained model exists)

Outputs a results table and saves to JSON + MLflow.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import time
import numpy as np

from environment.cost_model import CostModel
from baselines.hive_static import run_hive_baseline
from baselines.zorder import run_zorder_baseline

DATA_DIR = Path(__file__).parent.parent / "data"
ROOT = Path(__file__).parent.parent
RESULTS_DIR = ROOT / "benchmarks" / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def run_flat_baseline() -> dict:
    """Baseline: no partitioning at all."""
    cm = CostModel()
    cost = cm.measure(str(DATA_DIR / "sales_flat.parquet"))
    return {
        "method": "flat",
        "bytes_scanned_mb": cost["total_bytes_scanned"] / 1e6,
        "avg_latency_ms": cost["avg_latency_ms"],
        "bytes_improvement_pct": 0.0,
    }


def run_rl_benchmark() -> dict:
    """Run trained RL agent (if available) and return best partition stats."""
    model_path = ROOT / "agent" / "saved_models" / "best" / "best_model.zip"
    if not model_path.exists():
        print("  [rl] No trained model found. Skipping RL benchmark.")
        return {"method": "rl_ppo", "bytes_improvement_pct": None, "status": "not_trained"}

    try:
        from stable_baselines3 import PPO
        from environment.partition_env import PartitionEnv

        model = PPO.load(str(model_path.with_suffix("")))
        env = PartitionEnv(
            source_parquet=str(DATA_DIR / "sales_flat.parquet"),
            workload_path=str(DATA_DIR / "workload_log.json"),
            max_steps=20,
        )

        rewards = []
        best_info = None
        best_reward = -np.inf

        for ep in range(5):
            obs, info = env.reset()
            ep_reward = 0
            done = False
            while not done:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = env.step(action)
                ep_reward += reward
                done = terminated or truncated
                if reward > best_reward:
                    best_reward = reward
                    best_info = info
            rewards.append(ep_reward)

        return {
            "method": "rl_ppo",
            "mean_episode_reward": float(np.mean(rewards)),
            "best_reward": float(best_reward),
            "best_partition_key": best_info["action"]["partition_key"] if best_info else None,
            "best_granularity": best_info["action"]["granularity"] if best_info else None,
            "bytes_improvement_pct": best_reward * 100 if best_reward > 0 else 0.0,
        }
    except Exception as e:
        print(f"  [rl] Error: {e}")
        return {"method": "rl_ppo", "bytes_improvement_pct": None, "status": f"error: {e}"}


def print_results_table(results: list[dict]):
    print("\n" + "=" * 70)
    print(f"{'Method':<20} {'Bytes Scanned (MB)':<22} {'Latency (ms)':<16} {'Improvement'}")
    print("=" * 70)
    for r in results:
        method = r.get("method", "?")
        bytes_mb = r.get("bytes_scanned_mb") or r.get("flat_bytes_scanned_mb") or r.get("hive_bytes_scanned_mb") or r.get("zorder_bytes_scanned_mb") or 0
        latency = r.get("avg_latency_ms") or r.get("flat_avg_latency_ms") or r.get("hive_avg_latency_ms") or r.get("zorder_avg_latency_ms") or 0
        improvement = r.get("bytes_improvement_pct")
        imp_str = f"{improvement:.1f}%" if improvement is not None else "N/A"
        print(f"{method:<20} {bytes_mb:<22.1f} {latency:<16.1f} {imp_str}")
    print("=" * 70)


def run_all_benchmarks():
    print("\n" + "=" * 60)
    print("  LAKEHOUSE PARTITION OPTIMIZER — BENCHMARK SUITE")
    print("=" * 60)

    flat = DATA_DIR / "sales_flat.parquet"
    if not flat.exists():
        print("ERROR: Run workload/generator.py first to generate the dataset.")
        sys.exit(1)

    results = []

    print("\n[1/4] Flat baseline (no partitioning)...")
    flat_r = run_flat_baseline()
    results.append(flat_r)
    print(f"  Bytes scanned: {flat_r['bytes_scanned_mb']:.1f} MB | Latency: {flat_r['avg_latency_ms']:.1f} ms")

    print("\n[2/4] Hive static partitioning...")
    hive_r = run_hive_baseline()
    results.append(hive_r)
    print(f"  Improvement: {hive_r['bytes_improvement_pct']:.1f}%")

    print("\n[3/4] Z-ordering...")
    zorder_r = run_zorder_baseline()
    results.append(zorder_r)
    print(f"  Improvement: {zorder_r['bytes_improvement_pct']:.1f}%")

    print("\n[4/4] RL agent (PPO)...")
    rl_r = run_rl_benchmark()
    results.append(rl_r)

    print_results_table(results)

    # Save results
    ts = int(time.time())
    out_path = RESULTS_DIR / f"benchmark_{ts}.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\nResults saved to {out_path}")

    return results


if __name__ == "__main__":
    run_all_benchmarks()
