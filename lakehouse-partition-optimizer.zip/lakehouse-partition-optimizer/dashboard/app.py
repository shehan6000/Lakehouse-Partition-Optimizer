"""
dashboard/app.py
----------------
Streamlit live dashboard for the Lakehouse Partition Optimizer.
Shows: workload stats, partition scheme, reward curve, benchmark comparison.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import time
import glob
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

DATA_DIR = Path(__file__).parent.parent / "data"
RESULTS_DIR = Path(__file__).parent.parent / "benchmarks" / "results"
MLRUNS_DIR = Path(__file__).parent.parent / "mlruns"

st.set_page_config(
    page_title="Lakehouse Partition Optimizer",
    page_icon="🦆",
    layout="wide",
)

# -------------------------------------------------------------------------
# Styling
# -------------------------------------------------------------------------
st.markdown("""
<style>
    .metric-card {
        background: #1e2130;
        border-radius: 8px;
        padding: 16px;
        margin: 4px;
    }
    .stMetric label { font-size: 0.85rem; color: #888; }
    .stMetric [data-testid="stMetricValue"] { font-size: 1.8rem; font-weight: 700; }
</style>
""", unsafe_allow_html=True)

st.title("🦆 Lakehouse Partition Optimizer")
st.caption("RL-based adaptive Parquet partitioning · DuckDB + Gymnasium + Stable-Baselines3")

# -------------------------------------------------------------------------
# Sidebar
# -------------------------------------------------------------------------
with st.sidebar:
    st.header("Configuration")
    auto_refresh = st.checkbox("Auto-refresh (5s)", value=False)
    if auto_refresh:
        time.sleep(5)
        st.rerun()

    st.markdown("---")
    st.subheader("Dataset Info")
    flat = DATA_DIR / "sales_flat.parquet"
    if flat.exists():
        size_mb = flat.stat().st_size / 1e6
        st.metric("Flat Parquet Size", f"{size_mb:.1f} MB")
    else:
        st.warning("Dataset not generated yet. Run `workload/generator.py`.")

    workload_log = DATA_DIR / "workload_log.json"
    if workload_log.exists():
        with open(workload_log) as f:
            wl = json.load(f)
        st.metric("Workload Queries", len(wl))

# -------------------------------------------------------------------------
# Main tabs
# -------------------------------------------------------------------------
tab1, tab2, tab3, tab4 = st.tabs(["📊 Benchmark", "🔄 Workload", "🤖 RL Training", "ℹ️ Architecture"])

# ==================== TAB 1: Benchmark Results ====================
with tab1:
    st.subheader("Partition Strategy Comparison")

    result_files = sorted(RESULTS_DIR.glob("benchmark_*.json")) if RESULTS_DIR.exists() else []

    if result_files:
        latest = result_files[-1]
        with open(latest) as f:
            results = json.load(f)

        # Build comparison dataframe
        rows = []
        for r in results:
            method = r.get("method", "?")
            improvement = r.get("bytes_improvement_pct", 0) or 0
            latency = (
                r.get("avg_latency_ms")
                or r.get("hive_avg_latency_ms")
                or r.get("zorder_avg_latency_ms")
                or 0
            )
            bytes_mb = (
                r.get("bytes_scanned_mb")
                or r.get("hive_bytes_scanned_mb")
                or r.get("zorder_bytes_scanned_mb")
                or 0
            )
            rows.append({
                "Method": method.replace("_", " ").title(),
                "Bytes Scanned (MB)": bytes_mb,
                "Avg Latency (ms)": latency,
                "Scan Improvement %": improvement,
            })

        df = pd.DataFrame(rows)

        col1, col2 = st.columns([2, 3])
        with col1:
            st.dataframe(df.set_index("Method"), use_container_width=True)

        with col2:
            fig, ax = plt.subplots(figsize=(6, 3.5))
            fig.patch.set_facecolor("#0e1117")
            ax.set_facecolor("#0e1117")
            colors = ["#ef4444", "#f59e0b", "#3b82f6", "#22c55e"]
            bars = ax.barh(
                df["Method"],
                df["Scan Improvement %"],
                color=colors[: len(df)],
                edgecolor="none",
                height=0.5,
            )
            ax.set_xlabel("Scan Cost Reduction (%)", color="#aaa")
            ax.tick_params(colors="#aaa")
            ax.spines[["top", "right", "left"]].set_visible(False)
            ax.xaxis.set_major_formatter(mtick.PercentFormatter())
            for bar in bars:
                w = bar.get_width()
                ax.text(
                    max(w + 0.5, 1),
                    bar.get_y() + bar.get_height() / 2,
                    f"{w:.1f}%",
                    va="center",
                    color="white",
                    fontsize=9,
                )
            st.pyplot(fig, use_container_width=True)

        st.caption(f"Last run: {latest.name}")
    else:
        st.info("No benchmark results yet. Run `benchmarks/run_benchmark.py`.")

# ==================== TAB 2: Workload ====================
with tab2:
    st.subheader("Query Workload Analysis")

    if workload_log.exists():
        with open(workload_log) as f:
            workload = json.load(f)

        from collections import Counter
        pred_counts = Counter()
        template_counts = Counter()
        for entry in workload:
            for p in entry.get("predicates", []):
                pred_counts[p] += 1
            template_counts[entry.get("template_id", "?")] += 1

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Predicate Frequency**")
            pred_df = pd.DataFrame(
                pred_counts.most_common(8),
                columns=["Column", "Count"]
            ).set_index("Column")
            st.bar_chart(pred_df)

        with col2:
            st.markdown("**Query Template Distribution**")
            tmpl_df = pd.DataFrame(
                template_counts.most_common(),
                columns=["Template", "Count"]
            ).set_index("Template")
            st.bar_chart(tmpl_df)

        st.markdown("**Sample Queries**")
        sample = workload[:5]
        for q in sample:
            with st.expander(f"Query {q['query_id']}: {q['template_id']}"):
                st.code(q["sql"], language="sql")
    else:
        st.info("No workload log found. Run `workload/generator.py`.")

# ==================== TAB 3: RL Training ====================
with tab3:
    st.subheader("RL Agent Training Monitor")

    model_path = Path(__file__).parent.parent / "agent" / "saved_models" / "best" / "best_model.zip"
    if model_path.exists():
        st.success(f"✅ Trained model found: `{model_path.name}`")
    else:
        st.warning("No trained model yet. Run `agent/train.py`.")

    # Try to read MLflow runs
    try:
        import mlflow
        mlflow.set_tracking_uri("sqlite:///" + str(ROOT / "mlflow.db"))
        client = mlflow.tracking.MlflowClient()
        exps = client.search_experiments()
        if exps:
            exp = exps[0]
            runs = client.search_runs(
                experiment_ids=[exp.experiment_id],
                order_by=["start_time DESC"],
                max_results=5,
            )
            if runs:
                st.markdown("**Recent MLflow Runs**")
                run_data = []
                for run in runs:
                    run_data.append({
                        "Run": run.info.run_name or run.info.run_id[:8],
                        "Status": run.info.status,
                        "Mean Reward": run.data.metrics.get("mean_ep_reward", "—"),
                    })
                st.dataframe(pd.DataFrame(run_data), use_container_width=True)
            else:
                st.info("No MLflow runs recorded yet.")
    except Exception as e:
        st.info(f"MLflow not available: {e}")

    st.markdown("**Run training:**")
    st.code("python agent/train.py", language="bash")
    st.markdown("**Launch MLflow UI:**")
    st.code("mlflow ui --backend-store-uri mlruns", language="bash")

# ==================== TAB 4: Architecture ====================
with tab4:
    st.subheader("System Architecture")
    st.code("""
Query Workload
     │
     ▼
┌─────────────────┐
│ Workload Logger  │  ← intercepts DuckDB queries, logs predicates + accessed columns
└────────┬────────┘
         │ workload stats (column freq, predicate ranges, join keys)
         ▼
┌─────────────────┐
│  State Encoder   │  ← encodes (current partition scheme + workload stats) → state vector
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│    RL Agent      │  ← PPO agent (Stable-Baselines3)
│  (PPO / DQN)    │  action: (partition_key, granularity, sort_order)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Gym Environment │  ← applies action → re-partitions Parquet → runs probe queries
│  (DuckDB-based) │  reward: -bytes_scanned (scan cost reduction)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Re-partitioner  │  ← PyArrow: physically rewrites Parquet with new partition scheme
└─────────────────┘

Baselines: Hive static partitioning | Z-ordering (PyArrow)
Tracking:  MLflow
    """)

    st.subheader("Quick Start")
    st.code("""
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate dataset + workload
python workload/generator.py

# 3. Test the Gym environment
python environment/partition_env.py

# 4. Train the PPO agent
python agent/train.py

# 5. Run full benchmark
python benchmarks/run_benchmark.py

# 6. (Optional) Launch this dashboard
streamlit run dashboard/app.py
    """, language="bash")
