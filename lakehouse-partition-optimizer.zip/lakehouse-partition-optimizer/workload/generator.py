"""
workload/generator.py
---------------------
Generates a TPC-DS-style synthetic dataset and query workload.
Writes Parquet files to data/ directory.
"""

import duckdb
import pyarrow as pa
import pyarrow.parquet as pq
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta
import random
import json

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

SCALE_FACTOR = 1  # ~1GB dataset, increase for larger scale


def generate_sales_table(n_rows: int = 1_000_000) -> pa.Table:
    """Generate a fact table resembling store_sales from TPC-DS."""
    rng = np.random.default_rng(42)

    # Date dimension: 3 years of daily dates
    start_date = datetime(2021, 1, 1)
    dates = [start_date + timedelta(days=int(d)) for d in rng.integers(0, 365 * 3, n_rows)]
    sale_dates = [d.strftime("%Y-%m-%d") for d in dates]
    sale_years = [d.year for d in dates]
    sale_months = [d.month for d in dates]
    sale_days = [d.day for d in dates]

    # Category dimension (skewed — some categories dominate)
    categories = ["electronics", "clothing", "furniture", "food", "sports", "toys", "books", "auto"]
    category_weights = [0.30, 0.20, 0.10, 0.15, 0.08, 0.07, 0.06, 0.04]
    sale_categories = rng.choice(categories, n_rows, p=category_weights)

    # Region dimension
    regions = ["north", "south", "east", "west", "central"]
    sale_regions = rng.choice(regions, n_rows)

    # Store IDs (1-500)
    store_ids = rng.integers(1, 501, n_rows)

    # Customer IDs (1-100k, Zipf-distributed — some customers are heavy buyers)
    customer_ids = np.minimum(
        np.floor(np.abs(rng.zipf(1.5, n_rows) - 1) * 100).astype(int) + 1,
        100_000,
    )

    # Product IDs (1-10k)
    product_ids = rng.integers(1, 10_001, n_rows)

    # Revenue (log-normal)
    quantities = rng.integers(1, 11, n_rows)
    unit_prices = np.round(np.exp(rng.normal(3.5, 1.2, n_rows)), 2)
    revenues = np.round(quantities * unit_prices, 2)

    # Discount (0-30%)
    discounts = np.round(rng.uniform(0, 0.30, n_rows), 4)

    table = pa.table(
        {
            "sale_date": pa.array(sale_dates, type=pa.string()),
            "sale_year": pa.array(sale_years, type=pa.int32()),
            "sale_month": pa.array(sale_months, type=pa.int32()),
            "sale_day": pa.array(sale_days, type=pa.int32()),
            "category": pa.array(sale_categories.tolist(), type=pa.string()),
            "region": pa.array(sale_regions.tolist(), type=pa.string()),
            "store_id": pa.array(store_ids.tolist(), type=pa.int32()),
            "customer_id": pa.array(customer_ids.tolist(), type=pa.int64()),
            "product_id": pa.array(product_ids.tolist(), type=pa.int32()),
            "quantity": pa.array(quantities.tolist(), type=pa.int32()),
            "unit_price": pa.array(unit_prices.tolist(), type=pa.float64()),
            "revenue": pa.array(revenues.tolist(), type=pa.float64()),
            "discount": pa.array(discounts.tolist(), type=pa.float64()),
        }
    )
    return table


def write_baseline_parquet(table: pa.Table, partition_key: str = "sale_year"):
    """Write initial flat Parquet dataset (baseline: no partitioning)."""
    output_path = DATA_DIR / "sales_flat.parquet"
    pq.write_table(table, output_path, compression="snappy", row_group_size=100_000)
    print(f"[generator] Wrote flat Parquet: {output_path} ({output_path.stat().st_size / 1e6:.1f} MB)")
    return output_path


def write_partitioned_parquet(table: pa.Table, partition_cols: list[str]):
    """Write Hive-partitioned Parquet dataset."""
    output_path = DATA_DIR / "sales_partitioned"
    if output_path.exists():
        import shutil
        shutil.rmtree(output_path)
    pq.write_to_dataset(
        table,
        root_path=str(output_path),
        partition_cols=partition_cols,
        compression="snappy",
    )
    print(f"[generator] Wrote partitioned Parquet ({partition_cols}): {output_path}")
    return output_path


# ---------------------------------------------------------------------------
# Query workload templates
# ---------------------------------------------------------------------------

QUERY_TEMPLATES = [
    # Time-range heavy queries
    {
        "id": "Q1_monthly_revenue",
        "template": "SELECT sale_month, SUM(revenue) FROM sales WHERE sale_year = {year} GROUP BY sale_month",
        "predicates": ["sale_year"],
        "access_cols": ["sale_month", "revenue", "sale_year"],
        "weight": 0.20,
    },
    {
        "id": "Q2_category_revenue",
        "template": "SELECT category, SUM(revenue) FROM sales WHERE sale_year = {year} AND sale_month BETWEEN {m1} AND {m2} GROUP BY category ORDER BY 2 DESC",
        "predicates": ["sale_year", "sale_month"],
        "access_cols": ["category", "revenue", "sale_year", "sale_month"],
        "weight": 0.18,
    },
    {
        "id": "Q3_region_store",
        "template": "SELECT region, store_id, COUNT(*) as txns, SUM(revenue) as total FROM sales WHERE region = '{region}' AND sale_year = {year} GROUP BY region, store_id",
        "predicates": ["region", "sale_year"],
        "access_cols": ["region", "store_id", "revenue", "sale_year"],
        "weight": 0.15,
    },
    {
        "id": "Q4_top_customers",
        "template": "SELECT customer_id, SUM(revenue) as spend FROM sales WHERE category = '{category}' GROUP BY customer_id ORDER BY spend DESC LIMIT 100",
        "predicates": ["category"],
        "access_cols": ["customer_id", "revenue", "category"],
        "weight": 0.12,
    },
    {
        "id": "Q5_daily_trend",
        "template": "SELECT sale_date, SUM(revenue) FROM sales WHERE sale_year = {year} AND category = '{category}' GROUP BY sale_date ORDER BY sale_date",
        "predicates": ["sale_year", "category"],
        "access_cols": ["sale_date", "revenue", "sale_year", "category"],
        "weight": 0.10,
    },
    {
        "id": "Q6_discount_analysis",
        "template": "SELECT product_id, AVG(discount), SUM(revenue) FROM sales WHERE sale_month = {month} AND sale_year = {year} GROUP BY product_id HAVING SUM(revenue) > 1000",
        "predicates": ["sale_month", "sale_year"],
        "access_cols": ["product_id", "discount", "revenue", "sale_month", "sale_year"],
        "weight": 0.10,
    },
    {
        "id": "Q7_cross_region",
        "template": "SELECT region, category, SUM(revenue) FROM sales WHERE sale_year = {year} GROUP BY region, category",
        "predicates": ["sale_year"],
        "access_cols": ["region", "category", "revenue", "sale_year"],
        "weight": 0.08,
    },
    {
        "id": "Q8_full_scan",
        "template": "SELECT category, sale_year, SUM(revenue), COUNT(*) FROM sales GROUP BY category, sale_year",
        "predicates": [],
        "access_cols": ["category", "sale_year", "revenue"],
        "weight": 0.07,
    },
]


def generate_workload(n_queries: int = 200) -> list[dict]:
    """Generate a realistic query workload log."""
    rng = random.Random(42)
    templates = QUERY_TEMPLATES
    weights = [t["weight"] for t in templates]

    workload = []
    for i in range(n_queries):
        tmpl = rng.choices(templates, weights=weights)[0]
        params = {
            "year": rng.choice([2021, 2022, 2023]),
            "m1": rng.randint(1, 6),
            "m2": rng.randint(7, 12),
            "month": rng.randint(1, 12),
            "region": rng.choice(["north", "south", "east", "west", "central"]),
            "category": rng.choice(["electronics", "clothing", "furniture", "food", "sports"]),
        }
        sql = tmpl["template"].format(**params)
        entry = {
            "query_id": i,
            "template_id": tmpl["id"],
            "sql": sql,
            "predicates": tmpl["predicates"],
            "access_cols": tmpl["access_cols"],
            "params": params,
        }
        workload.append(entry)

    # Save workload log
    log_path = DATA_DIR / "workload_log.json"
    with open(log_path, "w") as f:
        json.dump(workload, f, indent=2)
    print(f"[generator] Wrote {n_queries} queries to {log_path}")
    return workload


if __name__ == "__main__":
    print("=== Lakehouse Partition Optimizer: Data Generator ===")
    n_rows = 1_000_000 * SCALE_FACTOR
    print(f"Generating {n_rows:,} rows (scale factor {SCALE_FACTOR})...")
    table = generate_sales_table(n_rows)
    write_baseline_parquet(table)
    write_partitioned_parquet(table, ["sale_year"])
    workload = generate_workload(200)
    print(f"\nDataset columns: {table.schema.names}")
    print(f"Workload: {len(workload)} queries across {len(QUERY_TEMPLATES)} templates")
    print("\nDone. Next: run environment/partition_env.py")
