"""
workload/encoder.py
-------------------
Encodes (current partition scheme + workload stats) into a fixed-size state vector
for the RL agent.
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional


# Partition key candidates (index into this list = part of action space)
PARTITION_KEYS = [
    "sale_year",       # 0
    "sale_month",      # 1
    "category",        # 2
    "region",          # 3
    "store_id",        # 4 (hash bucket)
    "customer_id",     # 5 (hash bucket)
    "none",            # 6 — no partitioning
]

GRANULARITIES = [
    "year",            # 0
    "month",           # 1
    "day",             # 2
    "hash_8",          # 3 — 8 hash buckets
    "hash_16",         # 4
    "hash_32",         # 5
    "hash_64",         # 6
    "value",           # 7 — partition by distinct value (categories, regions)
]

ALL_COLUMNS = [
    "sale_date", "sale_year", "sale_month", "sale_day",
    "category", "region", "store_id", "customer_id",
    "product_id", "quantity", "unit_price", "revenue", "discount",
]


@dataclass
class PartitionScheme:
    """Describes the current physical partitioning of the dataset."""
    partition_key: str = "sale_year"      # which column partitions files
    granularity: str = "year"             # granularity of partition
    sort_cols: list[str] = None           # within-partition sort order
    n_files: int = 1
    total_bytes: float = 0.0
    avg_file_bytes: float = 0.0

    def __post_init__(self):
        if self.sort_cols is None:
            self.sort_cols = []

    def to_index(self) -> tuple[int, int]:
        pk_idx = PARTITION_KEYS.index(self.partition_key) if self.partition_key in PARTITION_KEYS else 6
        gran_idx = GRANULARITIES.index(self.granularity) if self.granularity in GRANULARITIES else 0
        return pk_idx, gran_idx


class StateEncoder:
    """
    Encodes the full RL observation:
      - Current partition scheme (one-hot)
      - Workload stats (column frequencies, predicate frequencies)
      - Dataset stats (size, file count, etc.)
    
    Output: flat float32 numpy vector.
    """

    N_PARTITION_KEYS = len(PARTITION_KEYS)
    N_GRANULARITIES = len(GRANULARITIES)
    N_COLS = len(ALL_COLUMNS)

    # State vector dimensions:
    # partition_key one-hot: N_PARTITION_KEYS
    # granularity one-hot:   N_GRANULARITIES
    # col_access_freq:       N_COLS
    # predicate_freq:        N_COLS
    # dataset stats:         4 (n_files, total_bytes, avg_file_bytes, avg_latency)
    STATE_DIM = N_PARTITION_KEYS + N_GRANULARITIES + 2 * N_COLS + 4

    def encode(
        self,
        scheme: PartitionScheme,
        col_access_freq: Optional[dict] = None,
        predicate_freq: Optional[dict] = None,
        avg_latency_ms: float = 0.0,
        bytes_scanned_last: float = 0.0,
    ) -> np.ndarray:
        """Encode the current state into a fixed-size float32 vector."""
        vec = np.zeros(self.STATE_DIM, dtype=np.float32)
        offset = 0

        # Partition key one-hot
        pk_idx, gran_idx = scheme.to_index()
        vec[offset + pk_idx] = 1.0
        offset += self.N_PARTITION_KEYS

        # Granularity one-hot
        vec[offset + gran_idx] = 1.0
        offset += self.N_GRANULARITIES

        # Column access frequencies
        if col_access_freq:
            for i, col in enumerate(ALL_COLUMNS):
                vec[offset + i] = col_access_freq.get(col, 0.0)
        offset += self.N_COLS

        # Predicate frequencies
        if predicate_freq:
            for i, col in enumerate(ALL_COLUMNS):
                vec[offset + i] = predicate_freq.get(col, 0.0)
        offset += self.N_COLS

        # Dataset stats (normalized)
        vec[offset + 0] = min(scheme.n_files / 1000.0, 1.0)
        vec[offset + 1] = min(scheme.total_bytes / 1e9, 1.0)   # normalize to 1GB
        vec[offset + 2] = min(scheme.avg_file_bytes / 1e8, 1.0)
        vec[offset + 3] = min(avg_latency_ms / 10_000.0, 1.0)
        offset += 4

        assert offset == self.STATE_DIM
        return vec

    @property
    def observation_space_dim(self) -> int:
        return self.STATE_DIM


if __name__ == "__main__":
    encoder = StateEncoder()
    scheme = PartitionScheme(
        partition_key="sale_year",
        granularity="year",
        sort_cols=["category"],
        n_files=3,
        total_bytes=500_000_000,
    )
    col_freq = {"sale_year": 0.8, "category": 0.6, "revenue": 0.9}
    pred_freq = {"sale_year": 0.7, "category": 0.4}
    state = encoder.encode(scheme, col_freq, pred_freq, avg_latency_ms=120.0)
    print(f"State vector shape: {state.shape}")
    print(f"State vector (first 20): {state[:20]}")
    print(f"State dim: {encoder.observation_space_dim}")
