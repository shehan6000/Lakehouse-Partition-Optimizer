"""
workload/logger.py
------------------
DuckDB query interceptor + workload statistics aggregator.
Tracks column access frequencies, predicate ranges, and query patterns.
"""

import json
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional
import duckdb
import numpy as np

DATA_DIR = Path(__file__).parent.parent / "data"


@dataclass
class WorkloadStats:
    """Aggregated statistics derived from recent query history."""
    # Column access frequency (normalized 0-1)
    col_access_freq: dict[str, float] = field(default_factory=dict)
    # Predicate frequency per column (normalized 0-1)
    predicate_freq: dict[str, float] = field(default_factory=dict)
    # Predicate selectivity estimates per column
    predicate_selectivity: dict[str, float] = field(default_factory=dict)
    # Number of queries in window
    n_queries: int = 0
    # Bytes scanned history
    bytes_scanned_history: list[float] = field(default_factory=list)
    # Average query latency (ms)
    avg_latency_ms: float = 0.0


class WorkloadLogger:
    """
    Wraps DuckDB to intercept queries, log predicates and column accesses,
    and compute rolling workload statistics used as the RL state.
    """

    ALL_COLUMNS = [
        "sale_date", "sale_year", "sale_month", "sale_day",
        "category", "region", "store_id", "customer_id",
        "product_id", "quantity", "unit_price", "revenue", "discount",
    ]
    CATEGORICAL_COLS = {"category", "region"}
    TEMPORAL_COLS = {"sale_date", "sale_year", "sale_month", "sale_day"}
    NUMERIC_COLS = {"store_id", "customer_id", "product_id", "quantity", "unit_price", "revenue", "discount"}

    def __init__(self, db_path: str = ":memory:", window: int = 50):
        self.conn = duckdb.connect(db_path)
        self.window = window  # sliding window of last N queries
        self._log: list[dict] = []

    def load_table(self, parquet_path: str, table_name: str = "sales"):
        """Register a Parquet file (or directory) as a DuckDB view."""
        p = Path(parquet_path)
        if p.is_dir():
            pattern = str(p / "**/*.parquet")
            self.conn.execute(f"CREATE OR REPLACE VIEW {table_name} AS SELECT * FROM read_parquet('{pattern}', hive_partitioning=true)")
        else:
            self.conn.execute(f"CREATE OR REPLACE VIEW {table_name} AS SELECT * FROM read_parquet('{parquet_path}')")
        print(f"[logger] Loaded table '{table_name}' from {parquet_path}")

    def execute(self, sql: str, predicates: list[str] = None, access_cols: list[str] = None) -> tuple:
        """Run a query and log its statistics."""
        t0 = time.perf_counter()

        # Run EXPLAIN to get estimated bytes before execution
        try:
            explain = self.conn.execute(f"EXPLAIN ANALYZE {sql}").fetchall()
            explain_text = "\n".join(str(row) for row in explain)
        except Exception:
            explain_text = ""

        result = self.conn.execute(sql).fetchall()
        latency_ms = (time.perf_counter() - t0) * 1000

        # Estimate bytes scanned from DuckDB explain output
        bytes_scanned = self._estimate_bytes_scanned(explain_text)

        entry = {
            "sql": sql,
            "predicates": predicates or self._infer_predicates(sql),
            "access_cols": access_cols or self._infer_access_cols(sql),
            "latency_ms": latency_ms,
            "bytes_scanned": bytes_scanned,
            "timestamp": time.time(),
        }
        self._log.append(entry)
        # Keep only recent window
        if len(self._log) > self.window * 2:
            self._log = self._log[-self.window:]

        return result, latency_ms, bytes_scanned

    def get_stats(self) -> WorkloadStats:
        """Compute rolling workload statistics from recent query log."""
        window = self._log[-self.window:]
        if not window:
            return WorkloadStats()

        col_counts = defaultdict(int)
        pred_counts = defaultdict(int)
        total = len(window)

        for entry in window:
            for col in entry.get("access_cols", []):
                col_counts[col] += 1
            for col in entry.get("predicates", []):
                pred_counts[col] += 1

        # Normalize to frequencies
        col_freq = {col: col_counts[col] / total for col in self.ALL_COLUMNS}
        pred_freq = {col: pred_counts[col] / total for col in self.ALL_COLUMNS}

        bytes_history = [e["bytes_scanned"] for e in window]
        avg_latency = np.mean([e["latency_ms"] for e in window])

        return WorkloadStats(
            col_access_freq=col_freq,
            predicate_freq=pred_freq,
            predicate_selectivity={col: 0.0 for col in self.ALL_COLUMNS},  # placeholder
            n_queries=total,
            bytes_scanned_history=bytes_history,
            avg_latency_ms=float(avg_latency),
        )

    def get_stats_vector(self) -> np.ndarray:
        """Return workload stats as a flat numpy vector (for RL state encoder)."""
        stats = self.get_stats()
        vec = []
        for col in self.ALL_COLUMNS:
            vec.append(stats.col_access_freq.get(col, 0.0))
        for col in self.ALL_COLUMNS:
            vec.append(stats.predicate_freq.get(col, 0.0))
        vec.append(stats.avg_latency_ms / 10_000.0)  # normalize
        vec.append(len(self._log) / self.window)
        return np.array(vec, dtype=np.float32)

    def replay_workload(self, workload: list[dict]) -> list[tuple]:
        """Replay a saved workload and return (latency, bytes) for each query."""
        results = []
        for entry in workload:
            try:
                _, latency, bytes_scanned = self.execute(
                    entry["sql"],
                    predicates=entry.get("predicates"),
                    access_cols=entry.get("access_cols"),
                )
                results.append((latency, bytes_scanned))
            except Exception as e:
                print(f"[logger] Query failed: {e}")
                results.append((0.0, 0.0))
        return results

    def save_log(self, path: str):
        with open(path, "w") as f:
            json.dump(self._log, f, indent=2)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _estimate_bytes_scanned(self, explain_text: str) -> float:
        """Parse DuckDB EXPLAIN ANALYZE output to estimate bytes scanned."""
        # Look for scan operators and file sizes
        # Fallback: use a rough heuristic
        if "Rows Scanned" in explain_text:
            for line in explain_text.split("\n"):
                if "Rows Scanned" in line:
                    try:
                        rows = int(line.split(":")[-1].strip().replace(",", ""))
                        return rows * 64.0  # ~64 bytes per row estimate
                    except ValueError:
                        pass
        # Default heuristic
        return 64.0 * 1_000_000  # 64MB fallback

    def _infer_predicates(self, sql: str) -> list[str]:
        """Simple SQL parser to identify WHERE clause columns."""
        sql_upper = sql.upper()
        preds = []
        if "WHERE" not in sql_upper:
            return preds
        where_clause = sql_upper.split("WHERE")[1].split("GROUP")[0].split("ORDER")[0]
        for col in self.ALL_COLUMNS:
            if col.upper() in where_clause:
                preds.append(col)
        return preds

    def _infer_access_cols(self, sql: str) -> list[str]:
        """Identify columns referenced anywhere in the query."""
        sql_upper = sql.upper()
        return [col for col in self.ALL_COLUMNS if col.upper() in sql_upper]


if __name__ == "__main__":
    import json

    logger = WorkloadLogger()

    # Load data
    flat_path = DATA_DIR / "sales_flat.parquet"
    if not flat_path.exists():
        print("Run workload/generator.py first to create the dataset.")
    else:
        logger.load_table(str(flat_path))

        # Load workload
        wl_path = DATA_DIR / "workload_log.json"
        with open(wl_path) as f:
            workload = json.load(f)

        print(f"Replaying {len(workload)} queries...")
        results = logger.replay_workload(workload[:20])

        stats = logger.get_stats()
        print("\n=== Workload Stats ===")
        print(f"Queries in window: {stats.n_queries}")
        print(f"Avg latency: {stats.avg_latency_ms:.1f} ms")
        print(f"Top predicate columns: {sorted(stats.predicate_freq.items(), key=lambda x: -x[1])[:5]}")
        print(f"State vector shape: {logger.get_stats_vector().shape}")
